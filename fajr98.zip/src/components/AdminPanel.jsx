// src/app/admin/page.jsx

'use client';
import { useState } from 'react';

const pages = {
  about: ['page_title', 'title', 'content'],
  interduction: ['page_title', 'title', 'content', 'image'],
  registration: ['page_title', 'title', 'content', 'video'],
  news: ['page_title', 'title', 'content', 'image', 'date'],
  'student-work': ['page_title', 'title', 'content', 'image']
};

export default function AdminPanel() {
  const [page, setPage] = useState('about');
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(false);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const payload = {
      page_name: page,
      page_title: formData.page_title || '',
      title: formData.title || '',
      content: formData.content || '',
      media_url: formData.image || formData.video || '',
      media_type: formData.video ? 'video' : 'image',
      date: formData.date || null
    };

    try {
      const res = await fetch('/api/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const result = await res.json();

      if (res.ok) {
        alert('✅ با موفقیت ثبت شد');
        setFormData({});
      } else {
        alert(`❌ خطا: ${result.error}`);
      }
    } catch (err) {
      alert('خطا در اتصال به سرور');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">پنل مدیریت محتوا</h1>

      <label className="block mb-2 font-medium">صفحه مورد نظر:</label>
      <select
        value={page}
        onChange={(e) => {
          setPage(e.target.value);
          setFormData({});
        }}
        className="mb-4 p-2 border rounded w-full"
      >
        {Object.keys(pages).map(p => (
          <option key={p} value={p}>{p}</option>
        ))}
      </select>

      <form onSubmit={handleSubmit} className="space-y-4">
        {pages[page].includes('page_title') && (
          <input
            type="text"
            placeholder="عنوان صفحه (page_title)"
            value={formData.page_title || ''}
            onChange={(e) => handleChange('page_title', e.target.value)}
            className="w-full p-2 border rounded"
          />
        )}
        {pages[page].includes('title') && (
          <input
            type="text"
            placeholder="عنوان محتوا"
            value={formData.title || ''}
            onChange={(e) => handleChange('title', e.target.value)}
            className="w-full p-2 border rounded"
          />
        )}
        {pages[page].includes('content') && (
          <textarea
            placeholder="متن محتوا"
            value={formData.content || ''}
            onChange={(e) => handleChange('content', e.target.value)}
            className="w-full p-2 border rounded min-h-[100px]"
          />
        )}
        {pages[page].includes('image') && (
          <input
            type="text"
            placeholder="لینک عکس"
            value={formData.image || ''}
            onChange={(e) => handleChange('image', e.target.value)}
            className="w-full p-2 border rounded"
          />
        )}
        {pages[page].includes('video') && (
          <input
            type="text"
            placeholder="لینک ویدیو"
            value={formData.video || ''}
            onChange={(e) => handleChange('video', e.target.value)}
            className="w-full p-2 border rounded"
          />
        )}
        {pages[page].includes('date') && (
          <input
            type="date"
            value={formData.date || ''}
            onChange={(e) => handleChange('date', e.target.value)}
            className="w-full p-2 border rounded"
          />
        )}

        <button
          type="submit"
          className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
          disabled={loading}
        >
          {loading ? 'در حال ارسال...' : 'ذخیره محتوا'}
        </button>
      </form>
    </div>
  );
}
