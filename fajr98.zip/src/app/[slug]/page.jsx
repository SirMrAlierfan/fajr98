'use client';
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';

export default function Page() {
  const { slug } = useParams();
  const [data, setData] = useState(null);

  useEffect(() => {
    if (!slug) return;
  
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/content?page=${slug}`);
  
        if (!res.ok) {
          console.error("API response error:", res.status);
          return;
        }
  
        const text = await res.text();
        if (!text) {
          console.warn("Empty response body");
          return;
        }
  
        const json = JSON.parse(text);
        setData(json);
      } catch (error) {
        console.error("خطا در دریافت داده:", error);
      }
    };
  
    fetchData();
  }, [slug]);
  
  if (!data) return <p>در حال بارگذاری...</p>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">{data.title}</h1>
      <p>{data.content}</p>
      {data.media_url && (
        <div className="mt-4">
          {data.media_type === 'image' ? (
            <img src={data.media_url} alt="media" />
          ) : (
            <video src={data.media_url} controls />
          )}
        </div>
      )}
    </div>
  );
}
